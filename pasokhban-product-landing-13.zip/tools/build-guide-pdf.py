#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
سازندهٔ PDF راهنمای پاسخ‌بان
============================

این اسکریپت، فایل `product-landing/guide.html` را می‌خواند و همان محتوا را با
همان سیستم طراحی (فونت Vazirmatn، رنگ‌ها، چیپ‌های مسیر و کالوت‌ها) به یک PDF
چندصفحه‌ای A4 تبدیل می‌کند. نقطهٔ حقیقت محتوا همان صفحهٔ راهنما است؛ بنابراین
اگر متن راهنما را در HTML تغییر دادید، کافی است این اسکریپت را دوباره اجرا کنید:

    python3 tools/build-guide-pdf.py

خروجی: product-landing/pasokhban-guide-fa.pdf

نکته‌های فنی
------------
* شکل‌دهی حروف فارسی با `arabic-reshaper` و ترتیب دوجهته با `python-bidi` انجام
  می‌شود (ReportLab خودش HarfBuzz ندارد).
* شکستن خط با اندازه‌گیری واقعی عرض کلمه‌های شکل‌داده‌شده انجام می‌شود؛ بنابراین
  هیچ خطی از کادر بیرون نمی‌زند و تراز راست‌چین دقیق است.
* فونت‌ها به‌صورت زیرمجموعه در PDF جاسازی می‌شوند (بدون نیاز به فونت سیستم).
* اگر نویسه‌ای در هیچ‌کدام از فونت‌ها نباشد، اسکریپت با خطای واضح متوقف می‌شود.
"""

from __future__ import annotations

import html
import os
import re
import sys
from dataclasses import dataclass, field

import arabic_reshaper
from bidi.algorithm import get_display
from fontTools.ttLib import TTFont as FTFont
from reportlab.lib.colors import HexColor, Color
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas as rl_canvas

try:  # html5lib برای خواندن مطمئن ساختار HTML
    import html5lib
except ImportError:  # pragma: no cover
    sys.exit("html5lib لازم است:  pip install html5lib")

# ---------------------------------------------------------------------------
# مسیرها
# ---------------------------------------------------------------------------
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT_DIR = os.path.join(ROOT, "tools", "fonts")
GUIDE_HTML = os.path.join(ROOT, "product-landing", "guide.html")
OUT_PDF = os.path.join(ROOT, "product-landing", "pasokhban-guide-fa.pdf")
RELAY_GS = os.path.join(ROOT, "product-landing", "google-relay.gs")

FONT_FILES = {
    "Vazir": "Vazirmatn-Regular.ttf",
    "Vazir-Med": "Vazirmatn-Medium.ttf",
    "Vazir-Semi": "Vazirmatn-SemiBold.ttf",
    "Vazir-Bold": "Vazirmatn-Bold.ttf",
    "Vazir-XBold": "Vazirmatn-ExtraBold.ttf",
    "Mono": "JetBrainsMono-Medium.ttf",
}

# ---------------------------------------------------------------------------
# رنگ‌ها و اندازه‌ها (هم‌ارز توکن‌های assets/css/main.css)
# ---------------------------------------------------------------------------
C = {
    "bg": HexColor("#ffffff"),
    "page_bg": HexColor("#f7f9f9"),
    "surface": HexColor("#ffffff"),
    "surface2": HexColor("#eef3f3"),
    "line": HexColor("#e0e7e7"),
    "line_strong": HexColor("#c9d5d5"),
    "ink900": HexColor("#081a1f"),
    "ink800": HexColor("#0d252c"),
    "inkline": HexColor("#24424a"),
    "text": HexColor("#14282e"),
    "muted": HexColor("#4c6269"),
    "subtle": HexColor("#5c6e75"),
    "accent": HexColor("#0f7a87"),
    "accent_ink": HexColor("#0a5560"),
    "accent_soft": HexColor("#e2f2f4"),
    "accent_soft_line": HexColor("#c3e2e5"),
    "accent_on_dark": HexColor("#6fd8cf"),
    "on_dark": HexColor("#e8f1f0"),
    "on_dark_muted": HexColor("#a4b8bb"),
    "ok": HexColor("#106b4f"),
    "ok_soft": HexColor("#e4f3ec"),
    "warn": HexColor("#8a5a00"),
    "warn_soft": HexColor("#fbf1dc"),
    "warn_line": HexColor("#eddcb6"),
    "code_bg": HexColor("#0d252c"),
    "code_text": HexColor("#d7e6e6"),
    "code_comment": HexColor("#8fb0b3"),
    "code_kw": HexColor("#6fd8cf"),
}

S = {
    "display": 27,
    "h2": 17.5,
    "h3": 12.5,
    "h4": 11.3,
    "lead": 10.8,
    "body": 10.2,
    "sm": 9.6,
    "caption": 8.7,
    "micro": 8.0,
    "mono": 8.2,
    "lh_body": 1.95,
    "lh_head": 1.45,
}

A4_W, A4_H = 595.276, 841.89
MARGIN = 46.0
CONTENT_W = A4_W - MARGIN * 2
HEADER_H = 62.0
FOOTER_H = 40.0


# ---------------------------------------------------------------------------
# فونت‌ها
# ---------------------------------------------------------------------------
def register_fonts() -> None:
    for name, fname in FONT_FILES.items():
        path = os.path.join(FONT_DIR, fname)
        if not os.path.exists(path):
            sys.exit(f"فایل فونت پیدا نشد: {path}")
        pdfmetrics.registerFont(TTFont(name, path))
        # هم‌خانواده‌سازی برای متن بولد درون‌خطی
        pdfmetrics.registerFontFamily(name, normal=name, bold="Vazir-Bold", italic=name, boldItalic="Vazir-Bold")
    pdfmetrics.registerFontFamily("Vazir", normal="Vazir", bold="Vazir-Bold", italic="Vazir", boldItalic="Vazir-Bold")
    pdfmetrics.registerFontFamily("Vazir-Semi", normal="Vazir-Semi", bold="Vazir-Bold", italic="Vazir-Semi", boldItalic="Vazir-Bold")


COVERAGE: dict[str, set[int]] = {}


def load_coverage() -> None:
    for name, fname in FONT_FILES.items():
        ft = FTFont(os.path.join(FONT_DIR, fname), lazy=True)
        COVERAGE[name] = set(ft.getBestCmap().keys())


def missing_chars(text: str, fonts: tuple[str, ...] = ("Vazir", "Mono")) -> set[str]:
    known: set[int] = set()
    for f in fonts:
        known |= COVERAGE.get(f, set())
    return {ch for ch in text if ch not in "\n\r\t" and ord(ch) not in known}


# ---------------------------------------------------------------------------
# شکل‌دهی و دوجهته
# ---------------------------------------------------------------------------
ARABIC_RANGE = re.compile(r"[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]+")
_reshaper = arabic_reshaper.ArabicReshaper(
    {"delete_harakat": True, "support_ligatures": True, "use_unshaped_instead_of_isolated": True}
)


def reshape(text: str) -> str:
    """شکل‌دهی فقط بخش‌های فارسی/عربی؛ بقیهٔ متن دست‌نخورده می‌ماند."""
    return ARABIC_RANGE.sub(lambda m: _reshaper.reshape(m.group(0)), text)


def visual(text: str, base_dir: str | None = None) -> str:
    """ترتیب دوجهتهٔ نهایی برای رسم."""
    return get_display(reshape(text), base_dir=base_dir) if base_dir else get_display(reshape(text))


def is_arabic(ch: str) -> bool:
    return bool(ARABIC_RANGE.match(ch))


def split_runs(text: str) -> list[tuple[bool, str]]:
    """تقسیم یک خط به بازه‌های فارسی/غیرفارسی (برای انتخاب فونت)."""
    runs: list[tuple[bool, str]] = []
    for ch in text:
        a = is_arabic(ch)
        if runs and runs[-1][0] == a:
            runs[-1] = (a, runs[-1][1] + ch)
        else:
            runs.append((a, ch))
    return runs


def shaped_word(word: str) -> str:
    return reshape(word)


def text_width(text: str, font: str, size: float) -> float:
    return pdfmetrics.stringWidth(text, font, size)


def wrap_words(words: list[str], font: str, size: float, max_w: float) -> list[list[str]]:
    """شکستن خط با اندازه‌گیری عرض کلمه‌های شکل‌داده‌شده."""
    space = text_width(" ", font, size)
    lines: list[list[str]] = []
    cur: list[str] = []
    cur_w = 0.0
    for w in words:
        ww = text_width(shaped_word(w), font, size)
        add = ww if not cur else ww + space
        if cur and cur_w + add > max_w:
            lines.append(cur)
            cur, cur_w = [w], ww
        else:
            cur.append(w)
            cur_w += add
    if cur:
        lines.append(cur)
    return lines


# ---------------------------------------------------------------------------
# واژه‌های درون‌خطی با استایل متفاوت (کد، بولد)
# ---------------------------------------------------------------------------
@dataclass
class Run:
    text: str
    style: str = "body"  # body | bold | code | muted


@dataclass
class Block:
    kind: str
    payload: dict = field(default_factory=dict)


# ---------------------------------------------------------------------------
# موتور چیدمان
# ---------------------------------------------------------------------------
class Doc:
    """موتور کوچک چیدمان روی canvas: جریان عمودی از بالا به پایین با تراز راست."""

    def __init__(self, path: str) -> None:
        self.c = rl_canvas.Canvas(path, pagesize=(A4_W, A4_H))
        self.c.setTitle("راهنمای پاسخ‌بان — از نصب تا اولین پاسخ")
        self.c.setAuthor("اتحاد وردپرس")
        self.c.setSubject("راهنمای فارسی افزونهٔ پاسخ‌بان: نصب، تنظیمات، کانال‌های اعلان و عیب‌یابی")
        self.c.setKeywords("پاسخ‌بان, وردپرس, راهنما, چت هوشمند, پشتیبانی")
        self.page = 0
        self.y = 0.0
        self.toc_pages: dict[str, int] = {}
        self.collect_toc = False
        self._first_page_done = False

    # ---- صفحه ------------------------------------------------------------
    def new_page(self, footer: bool = True) -> None:
        # صفحهٔ اول از قبل توسط ReportLab باز است؛ فقط از صفحهٔ دوم به بعد
        # باید صفحهٔ جاری بسته شود، وگرنه یک صفحهٔ خالی ابتدای سند می‌افتد.
        if self.page:
            if footer:
                self._footer()
            self.c.showPage()
        self.page += 1
        self.y = A4_H - MARGIN - (HEADER_H if footer and self.page > 1 else 0)
        if footer and self.page > 1:
            self._running_header()
        self._page_bg()

    def _page_bg(self) -> None:
        self.c.setFillColor(C["page_bg"] if self.page > 1 else C["surface"])
        self.c.rect(0, 0, A4_W, A4_H, stroke=0, fill=1)

    def _running_header(self) -> None:
        top = A4_H - MARGIN + 14
        self.c.setFillColor(C["subtle"])
        self.c.setFont("Vazir-Med", S["micro"])
        self.c.drawRightString(MARGIN + CONTENT_W, top, visual("پاسخ‌بان — راهنمای رسمی افزونهٔ وردپرس"))
        self.c.setStrokeColor(C["line"])
        self.c.setLineWidth(0.6)
        self.c.line(MARGIN, top - 8, MARGIN + CONTENT_W, top - 8)

    def _footer(self) -> None:
        if self.page <= 1:  # جلد شماره نمی‌گیرد
            return
        y = MARGIN - 16
        self.c.setStrokeColor(C["line"])
        self.c.setLineWidth(0.6)
        self.c.line(MARGIN, y + 12, MARGIN + CONTENT_W, y + 12)
        self.c.setFillColor(C["subtle"])
        self.c.setFont("Vazir", S["micro"])
        self.c.drawRightString(MARGIN + CONTENT_W, y, visual("پاسخ‌بان · محصول اتحاد وردپرس"))
        self.c.drawString(MARGIN, y, visual(f"صفحهٔ {fa_num(self.page)}"))

    def finish(self) -> None:
        self._footer()
        self.c.showPage()
        self.c.save()

    # ---- جریان -----------------------------------------------------------
    def space(self, h: float) -> None:
        self.y -= h

    def need(self, h: float) -> None:
        if self.y - h < MARGIN + FOOTER_H - 12:
            self.new_page()

    # ---- نوشتن متن -------------------------------------------------------
    def _draw_line(self, words: list[str], font: str, size: float, color: Color, x_right: float, lh: float) -> None:
        line = " ".join(shaped_word(w) for w in words)
        disp = get_display(line)
        self.c.setFont(font, size)
        self.c.setFillColor(color)
        self.c.drawRightString(x_right, self.y, disp)
        self.y -= lh

    def paragraph(
        self,
        text: str | list[Run],
        *,
        font: str = "Vazir",
        size: float = S["body"],
        color: Color | None = None,
        lh: float | None = None,
        width: float | None = None,
        x_right: float | None = None,
        gap_after: float = 0.0,
        first_line_indent: float = 0.0,
    ) -> None:
        color = color or C["muted"]
        lh = lh or size * S["lh_body"]
        width = width or CONTENT_W
        x_right = x_right if x_right is not None else MARGIN + CONTENT_W
        runs = text if isinstance(text, list) else [Run(text)]
        # ساده‌سازی: هر Run به کلمه‌های خودش شکسته می‌شود؛ درون یک خط، Runهای
        # هم‌استایل به هم می‌چسبند. برای متن‌های این سند (تکه‌های کوتاه کد) کافی است.
        words: list[tuple[str, str]] = []
        for r in runs:
            f = font if r.style in ("body", "muted") else ("Mono" if r.style == "code" else "Vazir-Bold")
            col = color
            if r.style == "code":
                col = C["accent_ink"]
            elif r.style == "muted":
                col = C["muted"]
            for w in r.text.split():
                words.append((w, f))

        space = text_width(" ", font, size)
        lines: list[list[tuple[str, str]]] = []
        cur: list[tuple[str, str]] = []
        cur_w = 0.0
        for w, f in words:
            ww = text_width(shaped_word(w), f, size)
            add = ww if not cur else ww + space
            if cur and cur_w + add > width:
                lines.append(cur)
                cur, cur_w = [(w, f)], ww
            else:
                cur.append((w, f))
                cur_w += add
        if cur:
            lines.append(cur)

        for line in lines:
            # چاپ خط: بازه‌های هم‌فونت را جدا رسم می‌کنیم تا اعمال فونت‌های
            # متفاوت (مثلاً توکن‌های کد) درست انجام شود.
            self.need(lh)
            if all(f == line[0][1] for _, f in line):
                disp = get_display(" ".join(shaped_word(w) for w, _ in line))
                self.c.setFont(line[0][1], size)
                self.c.setFillColor(color if line[0][1] != "Mono" else C["accent_ink"])
                self.c.drawRightString(x_right, self.y, disp)
                self.y -= lh
                continue
            # خط مخلوط: از راست به چپ، کلمه‌به‌کلمه رسم می‌کنیم
            x = x_right
            for w, f in line:
                disp = get_display(shaped_word(w))
                ww = text_width(disp, f, size)
                self.c.setFont(f, size)
                self.c.setFillColor(C["accent_ink"] if f == "Mono" else color)
                self.c.drawString(x - ww, self.y, disp)
                x -= ww + text_width(" ", f, size)
            self.y -= lh
        if gap_after:
            self.y -= gap_after


def fa_num(n: int | str) -> str:
    digits = "۰۱۲۳۴۵۶۷۸۹"
    return "".join(digits[int(d)] if d.isdigit() else d for d in str(n))


# ---------------------------------------------------------------------------
# استخراج محتوا از guide.html
# ---------------------------------------------------------------------------
def clean(text: str) -> str:
    text = re.sub(r"\s+", " ", text or "")
    return text.strip()


def node_text(node) -> str:
    return clean("".join(node.itertext()))


def classes(node) -> set[str]:
    return set((node.get("class") or "").split())


def find_all(root, tag: str):
    return [e for e in root.iter() if getattr(e, "tag", None) == tag]


def query(root, tag: str, cls: str | None = None):
    for e in root.iter():
        if getattr(e, "tag", None) != tag:
            continue
        if cls is None or cls in classes(e):
            return e
    return None


def query_all(root, tag: str, cls: str | None = None):
    """همهٔ گره‌های یک تگ؛ اگر cls داده شود، فقط همان کلاس."""
    out = []
    for e in root.iter():
        if getattr(e, "tag", None) != tag:
            continue
        if cls is None or cls in classes(e):
            out.append(e)
    return out


def runs_of(node) -> list[Run]:
    """متن یک گره را به بازه‌های استایل‌دار تبدیل می‌کند (کد/بولد/عادی)."""
    out: list[Run] = []

    def walk(n, style: str) -> None:
        if n.text:
            out.append(Run(n.text, style))
        for ch in n:
            if getattr(ch, "tag", None) in ("svg", "button"):
                continue
            k = classes(ch)
            if "code" in k or ch.tag == "code":
                walk(ch, "code")
            elif ch.tag in ("b", "strong"):
                walk(ch, "bold")
            else:
                walk(ch, style)

    walk(node, "body")
    merged: list[Run] = []
    for r in out:
        if not r.text.strip():
            if merged and not merged[-1].text.endswith(" "):
                merged[-1].text += " "
            continue
        merged.append(Run(re.sub(r"\s+", " ", r.text), r.style))
    return [r for r in merged if r.text.strip()]


def chips(node) -> list[str]:
    """متن چیپ‌های مسیر (پاسخ‌بان > تنظیمات > ...) از روی آیکون‌های SVG."""
    parts: list[str] = []
    for ch in node.iter():
        if getattr(ch, "tag", None) == "use":
            continue
    text = clean("".join(ch for ch in node.itertext()))
    # در HTML، جداکننده‌ها آیکون SVG هستند؛ پس متن گره‌ها را یکی‌یکی برمی‌داریم
    parts = [clean(t) for t in node.itertext() if clean(t)]
    return parts


@dataclass
class Step:
    label: str
    title: str
    body: str
    path: list[str] = field(default_factory=list)


@dataclass
class Setting:
    title: str
    body: str
    path: list[str] = field(default_factory=list)


@dataclass
class ChannelBlock:
    title: str
    intro: str = ""
    steps: list[str] = field(default_factory=list)
    path: list[str] = field(default_factory=list)
    code: list[str] = field(default_factory=list)
    note: str = ""
    warn_title: str = ""
    warn_body: str = ""


@dataclass
class Section:
    num: str
    id: str
    eyebrow: str
    title: str
    lead: str
    # محتوا بر اساس نوع بخش
    steps: list[Step] = field(default_factory=list)
    settings: list[Setting] = field(default_factory=list)
    channels: list[ChannelBlock] = field(default_factory=list)
    callout: tuple[str, str] | None = None
    prose: list[tuple[str, str]] = field(default_factory=list)
    faq: list[tuple[str, str]] = field(default_factory=list)
    checklist: list[str] = field(default_factory=list)
    table: list[tuple[str, list[str]]] = field(default_factory=list)
    table_caption: str = ""
    mock: bool = False


def extract() -> dict:
    src = open(GUIDE_HTML, encoding="utf-8").read()
    doc = html5lib.parse(src, namespaceHTMLElements=False)
    body = find_all(doc, "body")[0]

    hero = query(body, "section", "docs-hero")
    h1 = query(hero, "h1")
    accent_el = None
    for child in h1:
        if getattr(child, "tag", None) == "span" and "accent" in classes(child):
            accent_el = child
            break
    accent_text = node_text(accent_el) if accent_el is not None else ""
    data: dict = {
        "eyebrow": node_text(query(hero, "p", "eyebrow")),
        "title": clean(node_text(h1).replace(accent_text, "")),
        "title_accent": accent_text,
        "lead": node_text(query(hero, "p", "docs-hero__lead")),
        "meta": [],
    }
    meta_ul = query(hero, "ul", "docs-hero__meta")
    data["meta"] = [node_text(li) for li in find_all(meta_ul, "li")]

    article = query(body, "article", "docs-article")
    sections: list[Section] = []
    for sec in query_all(article, "section", "doc-section"):
        head = query(sec, "div", "doc-section__head")
        h2 = query(head, "h2")
        num_el = query(h2, "span", "doc-section__num")
        num = node_text(num_el)
        title = clean(node_text(h2).replace(num, ""))
        s = Section(
            num=num,
            id=sec.get("id") or title,
            eyebrow=node_text(query(head, "p", "eyebrow")),
            title=title,
            lead=node_text(find_all(head, "p")[-1]) if find_all(head, "p") else "",
        )

        # --- گام‌ها (فصل ۰۱)
        steps_box = query(sec, "div", "steps")
        if steps_box:
            for st in query_all(steps_box, "article", "step"):
                path_el = query(st, "span", "path")
                s.steps.append(
                    Step(
                        label=node_text(query(st, "span", "step__num")),
                        title=node_text(find_all(st, "h3")[0]) if find_all(st, "h3") else "",
                        body=node_text(find_all(st, "p")[0]) if find_all(st, "p") else "",
                        path=chips(path_el) if path_el is not None else [],
                    )
                )

        # --- تنظیمات (فصل ۰۲)
        grid = query(sec, "div", "setting-grid")
        if grid:
            for it in query_all(grid, "article", "setting"):
                path_el = query(it, "span", "path")
                s.settings.append(
                    Setting(
                        title=node_text(query(it, "h3")),
                        body=node_text(find_all(it, "p")[0]) if find_all(it, "p") else "",
                        path=chips(path_el) if path_el is not None else [],
                    )
                )

        # --- کانال‌ها (فصل ۰۳)
        cdoc = query(sec, "div", "channel-doc")
        if cdoc:
            for blk in query_all(cdoc, "article", "channel-block"):
                head3 = query(blk, "h3")
                cb = ChannelBlock(title=node_text(head3))
                ol = query(blk, "ol", "steps-list")
                if ol:
                    cb.steps = [node_text(li) for li in find_all(ol, "li")]
                pr = query(blk, "p", "prose")
                if pr is not None:
                    cb.intro = node_text(pr)
                path_el = None
                for cand in blk.iter():
                    if getattr(cand, "tag", None) == "span" and "path" in classes(cand):
                        path_el = cand
                        break
                if path_el is not None:
                    cb.path = chips(path_el)
                pre = None
                for cand in blk.iter():
                    if getattr(cand, "tag", None) == "code" and cand.get("id") == "relay-code":
                        pre = cand
                if pre is not None:
                    cb.code = [html.unescape(t) for t in pre.itertext()][0].split("\n")
                    cb.code = [line.rstrip("\r") for line in re.split(r"\r?\n", html.unescape("".join(pre.itertext())))]
                warn = query(blk, "div", "callout--warn") or query(blk, "div", "callout")
                if warn is not None:
                    tt = query(warn, "span", "callout__title")
                    cb.warn_title = node_text(tt) if tt is not None else ""
                    cb.warn_body = clean(node_text(warn).replace(cb.warn_title, ""))
                s.channels.append(cb)

        # --- کالوت عمومی
        cal = None
        for cand in sec.iter():
            if getattr(cand, "tag", None) == "div" and "callout" in classes(cand) and "callout--warn" not in classes(cand):
                cal = cand
                break
        if cal is not None:
            tt = query(cal, "span", "callout__title")
            title = node_text(tt) if tt is not None else ""
            s.callout = (title, clean(node_text(cal).replace(title, "")))

        # --- کار روزمره (فصل ۰۴)
        if query(sec, "div", "app") is not None:
            s.mock = True
            prose_box = query(sec, "div", "prose")
            if prose_box is not None:
                for e in prose_box:
                    tag = getattr(e, "tag", None)
                    if tag == "h3":
                        s.prose.append(("h3", node_text(e)))
                    elif tag == "p":
                        s.prose.append(("p", node_text(e)))

        # --- پرسش‌ها (فصل ۰۵)
        acc = query(sec, "div", "accordion")
        if acc:
            for det in query_all(acc, "details"):
                sm = query(det, "summary")
                body_el = query(det, "div", "accordion__body")
                s.faq.append((node_text(sm), node_text(body_el) if body_el is not None else ""))

        # --- چک‌لیست (فصل ۰۶)
        cl = query(sec, "ul", "release-checklist")
        if cl:
            s.checklist = [node_text(li) for li in find_all(cl, "li")]

        # --- جدول مرجع (فصل ۰۷)
        tw = query(sec, "div", "table-wrap")
        if tw:
            cap = query(tw, "caption")
            s.table_caption = node_text(cap) if cap is not None else ""
            tbody = query(tw, "tbody")
            if tbody is not None:
                for tr in find_all(tbody, "tr"):
                    cells = [e for e in tr if getattr(e, "tag", None) in ("th", "td")]
                    if len(cells) != 2:
                        continue
                    s.table.append((node_text(cells[0]), chips(cells[1])))
        # کالوت هشدار فصل ۰۷
        warn = query(sec, "div", "callout--warn")
        if warn is not None and s.callout is None:
            tt = query(warn, "span", "callout__title")
            title = node_text(tt) if tt is not None else ""
            s.callout = (title, clean(node_text(warn).replace(title, "")))

        sections.append(s)

    data["sections"] = sections
    toc = query(body, "ul", "docs-toc__list")
    data["toc"] = [node_text(a) for a in find_all(toc, "a")] if toc is not None else []
    return data


# ---------------------------------------------------------------------------
# محتوای کد رله (از فایل اصلی، هم‌ارز با صفحهٔ راهنما)
# ---------------------------------------------------------------------------
def relay_lines() -> list[str]:
    text = open(RELAY_GS, encoding="utf-8").read().replace("\t", "    ")
    return text.split("\n")


# ---------------------------------------------------------------------------
# رسم اجزای طراحی
# ---------------------------------------------------------------------------
def draw_mark(c, x, y, size, stroke, accent, bg):
    """نشان پاسخ‌بان: دو حباب گفتگو."""
    s = size / 32.0
    c.saveState()
    c.setLineJoin(1)
    c.setLineWidth(max(1.0, 1.5 * s))
    # حباب پشت
    c.setFillColor(bg)
    c.setStrokeColor(stroke)
    c.roundRect(x + 4.6 * s, y - 16.0 * s, 16.6 * s, 10.6 * s, 3.2 * s, stroke=1, fill=1)
    p = c.beginPath()
    p.moveTo(x + 8.4 * s, y - 15.6 * s)
    p.lineTo(x + 6.0 * s, y - 19.6 * s)
    p.lineTo(x + 11.4 * s, y - 15.8 * s)
    c.setFillColor(bg)
    c.setStrokeColor(stroke)
    c.drawPath(p, stroke=1, fill=1)
    # حباب جلو
    c.setFillColor(accent)
    c.setStrokeColor(accent)
    c.roundRect(x + 11.6 * s, y - 23.4 * s, 16.2 * s, 10.2 * s, 3.0 * s, stroke=0, fill=1)
    p = c.beginPath()
    p.moveTo(x + 22.6 * s, y - 23.2 * s)
    p.lineTo(x + 25.4 * s, y - 26.6 * s)
    p.lineTo(x + 20.4 * s, y - 23.5 * s)
    c.drawPath(p, stroke=0, fill=1)
    c.restoreState()


def chevron(c, x_right: float, y: float, size: float, color: Color, direction: str = "left") -> None:
    c.saveState()
    c.setStrokeColor(color)
    c.setLineWidth(1.1)
    c.setLineCap(1)
    p = c.beginPath()
    if direction == "left":  # ‹
        p.moveTo(x_right, y + size / 2)
        p.lineTo(x_right - size / 2, y)
        p.lineTo(x_right, y - size / 2)
    else:  # ›
        p.moveTo(x_right - size, y + size / 2)
        p.lineTo(x_right - size / 2, y)
        p.lineTo(x_right - size, y - size / 2)
    c.drawPath(p, stroke=1, fill=0)
    c.restoreState()


def chip(c, parts: list[str], y: float, *, size: float = S["micro"], max_w: float | None = None, x_right: float | None = None) -> float:
    """چیپ مسیر: پاسخ‌بان ‹ تنظیمات ‹ اتصال — از راست به چپ. y را برمی‌گرداند."""
    x_right = x_right if x_right is not None else MARGIN + CONTENT_W
    max_w = max_w or CONTENT_W
    pad_x, pad_y = 7.0, 4.6
    font, font_s = "Vazir-Med", size
    gap = 2.0
    line_parts: list[list[str]] = []
    cur: list[str] = []
    cur_w = 0.0
    for part in parts:
        w = text_width(visual(part), font, font_s)
        add = w + (gap + 7.0 if cur else 0)
        if cur and cur_w + add + pad_x * 2 > max_w:
            line_parts.append(cur)
            cur, cur_w = [part], w
        else:
            cur.append(part)
            cur_w += add
    if cur:
        line_parts.append(cur)
    for row in line_parts:
        widths = [text_width(visual(t), font, font_s) for t in row]
        total = sum(widths) + (len(row) - 1) * (gap + 7.0) + pad_x * 2
        h = font_s + pad_y * 2
        x = x_right - total
        c.setFillColor(C["surface2"])
        c.setStrokeColor(C["line"])
        c.setLineWidth(0.6)
        c.roundRect(x, y - h + 3, total, h, 5, stroke=1, fill=1)
        cx = x + pad_x
        for i, t in enumerate(row):
            c.setFillColor(C["subtle"])
            c.setFont(font, font_s)
            c.drawString(cx, y - h + 3 + pad_y + 0.6, visual(t))
            cx += widths[i]
            if i < len(row) - 1:
                c.setFillColor(C["subtle"])
                chevron(c, cx + gap + 5.5, y - h + 3 + (pad_y + font_s * 0.35), 5.0, C["subtle"], "left")
                cx += gap + 7.0
        y -= h + 6
    return y


def section_head(d: Doc, sec: Section) -> None:
    d.need(96)
    if sec.id in d.toc_pages or d.collect_toc:
        d.toc_pages[sec.id] = d.page
    y = d.y
    c = d.c
    # خط تیرهٔ تأکیدی در کنار شمارهٔ فصل
    c.setFillColor(C["accent"])
    c.setFont("Vazir-Semi", S["caption"])
    c.drawRightString(MARGIN + CONTENT_W, y, visual(sec.num))
    y -= 15
    c.setFillColor(C["ink900"])
    c.setFont("Vazir-Bold", S["h2"])
    c.drawRightString(MARGIN + CONTENT_W, y, visual(sec.title))
    y -= 13
    # خط جداکننده
    c.setStrokeColor(C["line"])
    c.setLineWidth(0.8)
    c.line(MARGIN, y, MARGIN + CONTENT_W, y)
    y -= 16
    d.y = y
    if sec.lead:
        d.paragraph(sec.lead, size=S["sm"], color=C["muted"], gap_after=10)


def callout(d: Doc, title: str, body: str, *, kind: str = "info") -> None:
    c = d.c
    font = "Vazir-Med"
    size = S["sm"]
    inner_w = CONTENT_W - 34
    lines = wrap_words(body.split(), font, size, inner_w)
    h = 26 + len(lines) * (size * 1.85)
    d.need(h + 12)
    x = MARGIN
    y = d.y
    bg = C["accent_soft"] if kind == "info" else C["warn_soft"]
    ln = C["accent_soft_line"] if kind == "info" else C["warn_line"]
    bar = C["accent"] if kind == "info" else C["warn"]
    txt = C["accent_ink"] if kind == "info" else HexColor("#5f3f00")
    c.setFillColor(bg)
    c.setStrokeColor(ln)
    c.setLineWidth(0.7)
    c.roundRect(x, y - h, CONTENT_W, h, 8, stroke=1, fill=1)
    # نوار تأکیدی سمت راست (شروع خط در RTL)
    c.setFillColor(bar)
    c.roundRect(x + CONTENT_W - 3.6, y - h, 3.6, h, 1.8, stroke=0, fill=1)
    cy = y - 17
    c.setFillColor(txt)
    if title:
        c.setFont("Vazir-Semi", S["caption"])
        c.drawRightString(x + CONTENT_W - 16, cy, visual(title))
        cy -= 14
    c.setFont(font, size)
    for line in lines:
        c.drawRightString(x + CONTENT_W - 16, cy, get_display(" ".join(shaped_word(w) for w in line)))
        cy -= size * 1.85
    d.y = y - h - 12


PERSIAN_RE = re.compile(r"[\u0600-\u06FF]")
COMMENT_RE = re.compile(r"^(\s*)(/\*+|\*/|\*|//)(\s*)")


def _mixed_word_width(word: str, size: float) -> float:
    """عرض یک کلمهٔ ترکیبی (فارسی/لاتین) با فونت‌های متناظر."""
    total = 0.0
    for is_ar, chunk in split_runs(word):
        if is_ar:
            total += pdfmetrics.stringWidth(get_display(chunk, base_dir="R"), "Vazir", size)
        else:
            total += pdfmetrics.stringWidth(chunk, "Mono", size)
    return total


def _draw_comment_line(c, text: str, x_right: float, y: float, size: float, max_w: float) -> float:
    """خط کامنتِ فارسی را به‌صورت یک پاراگراف راست‌چین (با شکست خط) رسم می‌کند."""
    m = COMMENT_RE.match(text)
    marker = ""
    body = text
    if m:
        marker = (m.group(2) or "").strip()
        body = text[m.end():]
    vfont = "Vazir"
    vsize = size * 0.98
    lh = size * 1.72
    space = pdfmetrics.stringWidth(" ", vfont, vsize)
    marker_w = pdfmetrics.stringWidth(marker + " ", "Mono", size) if marker else 0.0
    limit = max_w - marker_w

    rows: list[list[str]] = []
    cur: list[str] = []
    cur_w = 0.0
    for w in body.split():
        ww = _mixed_word_width(w, vsize)
        add = ww if not cur else ww + space
        if cur and cur_w + add > limit:
            rows.append(cur)
            cur, cur_w = [w], ww
        else:
            cur.append(w)
            cur_w += add
    if cur:
        rows.append(cur)

    for i, row in enumerate(rows):
        yy = y - i * lh
        if i == 0 and marker:
            c.setFont("Mono", size)
            c.setFillColor(C["code_comment"])
            c.drawString(x_right - marker_w + 2, yy, marker)
        c.setFont(vfont, vsize)
        c.setFillColor(C["code_comment"])
        c.drawRightString(x_right - marker_w, yy, get_display(" ".join(row), base_dir="R"))
    return len(rows) * lh


def _estimate_comment_height(line: str, size: float, inner_w: float) -> float:
    """تخمین ارتفاع یک خط کامنت فارسی پس از شکست خط (هم‌ارز منطق رسم)."""
    m = COMMENT_RE.match(line)
    marker = (m.group(2) or "").strip() if m else ""
    body = line[m.end():] if m else line
    marker_w = pdfmetrics.stringWidth(marker + " ", "Mono", size) if marker else 0.0
    limit = inner_w - marker_w
    vsize = size * 0.98
    space = pdfmetrics.stringWidth(" ", "Vazir", vsize)
    n, cur_w = 1, 0.0
    for w in body.split():
        ww = _mixed_word_width(w, vsize)
        add = ww if cur_w == 0 else ww + space
        if cur_w and cur_w + add > limit:
            n += 1
            cur_w = ww
        else:
            cur_w += add
    return n * size * 1.72


def _line_height(line: str, size: float, inner_w: float, lh: float) -> float:
    """ارتفاع مصرفی یک خط از بلوک کد (کامنت فارسی ممکن است چندخط شود)."""
    if COMMENT_RE.match(line) and PERSIAN_RE.search(line):
        return _estimate_comment_height(line, size, inner_w)
    return lh


def _draw_code_line(c, line: str, x_left: float, x_right: float, y: float, size: float, inner_w: float,
                    *, comment_wrap: bool = False) -> float:
    """یک خط کد رسم می‌کند. برای کامنت فارسی، ارتفاع مصرف‌شده را برمی‌گرداند."""
    if not line.strip():
        return 0.0
    if comment_wrap and COMMENT_RE.match(line) and PERSIAN_RE.search(line):
        return _draw_comment_line(c, line.rstrip(), x_right, y, size, inner_w)
    # خط کد واقعی یا کامنت لاتین: پایه LTR
    x = x_left
    for is_ar, chunk in split_runs(line):
        if is_ar:
            disp = get_display(chunk, base_dir="L")
            c.setFont("Vazir", size * 0.98)
            c.setFillColor(C["code_comment"])
            c.drawString(x, y, disp)
            x += pdfmetrics.stringWidth(disp, "Vazir", size * 0.98)
        else:
            c.setFont("Mono", size)
            c.setFillColor(C["code_text"])
            c.drawString(x, y, chunk)
            x += pdfmetrics.stringWidth(chunk, "Mono", size)
    return 0.0


def code_block(d: Doc, lines: list[str], title: str) -> None:
    c = d.c
    size = S["mono"]
    lh = size * 1.72
    pad = 11.0
    max_chars_w = CONTENT_W - pad * 2 - 12
    # شکستن خطوط بلند کد
    out: list[str] = []
    for line in lines:
        if text_width(line, "Mono", size) <= max_chars_w:
            out.append(line)
            continue
        rest = line
        while text_width(rest, "Mono", size) > max_chars_w:
            cut = len(rest)
            while cut > 1 and text_width(rest[:cut], "Mono", size) > max_chars_w:
                cut -= 1
            out.append(rest[:cut])
            rest = "    " + rest[cut:]
        out.append(rest)

    bar_h = 22.0
    inner_w = CONTENT_W - pad * 2

    i = 0
    while i < len(out):
        d.need(140)
        avail = d.y - (MARGIN + FOOTER_H + 10) - pad * 2 - bar_h
        chunk: list[str] = []
        used = 0.0
        while i < len(out):
            h = _line_height(out[i], size, inner_w, lh)
            if used + h > avail and chunk:
                break
            chunk.append(out[i])
            used += h
            i += 1
        h = bar_h + pad * 2 + used
        y = d.y
        c.setFillColor(C["code_bg"])
        c.setStrokeColor(C["line"])
        c.setLineWidth(0.6)
        c.roundRect(MARGIN, y - h, CONTENT_W, h, 8, stroke=1, fill=1)
        c.setFillColor(C["inkline"])
        c.rect(MARGIN, y - bar_h, CONTENT_W, bar_h, stroke=0, fill=1)
        c.setFillColor(C["accent_on_dark"])
        c.setFont("Mono", S["micro"])
        c.drawString(MARGIN + 11, y - bar_h + 7.5, title)
        if i < len(out):
            c.setFillColor(C["on_dark_muted"])
            c.setFont("Vazir", S["micro"])
            c.drawRightString(MARGIN + CONTENT_W - 11, y - bar_h + 7.5, visual("ادامه در صفحهٔ بعد"))
        cy = y - bar_h - pad - size
        for ln in chunk:
            step = _draw_code_line(c, ln, MARGIN + pad, MARGIN + CONTENT_W - pad, cy, size, inner_w, comment_wrap=True)
            cy -= (step if step else lh) + 0
        d.y = y - h - 12


def card(d: Doc, title: str, body: str, path: list[str] | None = None, *, badge: str | None = None) -> None:
    c = d.c
    inner_w = CONTENT_W - 32
    lines = wrap_words(body.split(), "Vazir", S["sm"], inner_w) if body else []
    h = 20 + (18 if title else 0) + len(lines) * (S["sm"] * 1.9) + (18 if path else 0) + (14 if badge else 0)
    d.need(h + 12)
    y = d.y
    c.setFillColor(C["surface"])
    c.setStrokeColor(C["line"])
    c.setLineWidth(0.7)
    c.roundRect(MARGIN, y - h, CONTENT_W, h, 9, stroke=1, fill=1)
    cy = y - 20
    if badge:
        c.setFillColor(C["accent_ink"])
        c.setFont("Vazir-Semi", S["caption"])
        c.drawRightString(MARGIN + CONTENT_W - 16, cy, visual(badge))
        cy -= 15
    if title:
        c.setFillColor(C["accent_ink"])
        c.setFont("Vazir-Bold", S["h4"])
        c.drawRightString(MARGIN + CONTENT_W - 16, cy, visual(title))
        cy -= 16
    c.setFillColor(C["muted"])
    c.setFont("Vazir", S["sm"])
    for line in lines:
        c.drawRightString(MARGIN + CONTENT_W - 16, cy, get_display(" ".join(shaped_word(w) for w in line)))
        cy -= S["sm"] * 1.9
    if path:
        chip(c, path, cy + 4, x_right=MARGIN + CONTENT_W - 16)
    d.y = y - h - 12


def numbered_item(d: Doc, index: str, text: str, *, x_right: float | None = None, width: float | None = None) -> None:
    """مورد فهرست شماره‌دار: شماره در یک مربع کوچک، متن راست‌چین."""
    c = d.c
    x_right = x_right if x_right is not None else MARGIN + CONTENT_W
    width = width or CONTENT_W
    box = 15.0
    text_w = width - box - 10
    lines = wrap_words(text.split(), "Vazir", S["sm"], text_w)
    lh = S["sm"] * 1.9
    d.need(len(lines) * lh + 6)
    y = d.y
    c.setFillColor(C["surface2"])
    c.roundRect(x_right - box, y - box + 3, box, box, 4, stroke=0, fill=1)
    c.setFillColor(C["accent_ink"])
    c.setFont("Vazir-Semi", S["micro"])
    c.drawCentredString(x_right - box / 2, y - box + 6.4, visual(index))
    cy = y
    c.setFillColor(C["muted"])
    c.setFont("Vazir", S["sm"])
    for line in lines:
        c.drawRightString(x_right - box - 10, cy, get_display(" ".join(shaped_word(w) for w in line)))
        cy -= lh
    d.y = min(cy, y - box - 4) + 5


def product_mock(d: Doc) -> None:
    """نمای کوچک پنجرهٔ پیشخوان پاسخ‌بان (هم‌ارز ماکت صفحهٔ راهنما)."""
    c = d.c
    w = CONTENT_W
    h = 178.0
    d.need(h + 14)
    y = d.y
    c.setFillColor(C["surface"])
    c.setStrokeColor(C["line_strong"])
    c.setLineWidth(0.8)
    c.roundRect(MARGIN, y - h, w, h, 10, stroke=1, fill=1)
    # نوار بالا
    c.setFillColor(C["surface2"])
    c.rect(MARGIN, y - 26, w, 26, stroke=0, fill=1)
    c.setFillColor(C["line_strong"])
    for i in range(3):
        c.circle(MARGIN + 14 + i * 9, y - 13, 2.6, stroke=0, fill=1)
    c.setFillColor(C["muted"])
    c.setFont("Vazir-Med", S["micro"])
    c.drawRightString(MARGIN + w - 12, y - 18, visual("پاسخ‌بان · گفتگوهای آنلاین"))
    # پنل فهرست
    list_w = 128.0
    c.setFillColor(C["surface"])
    c.rect(MARGIN + w - list_w, y - h, list_w, h - 26, stroke=0, fill=1)
    c.setStrokeColor(C["line"])
    c.line(MARGIN + w - list_w, y - h, MARGIN + w - list_w, y - 26)
    cy = y - 40
    c.setFillColor(C["ink900"])
    c.setFont("Vazir-Semi", S["micro"])
    c.drawRightString(MARGIN + w - 12, cy, visual("گفتگوها"))
    c.setFillColor(C["subtle"])
    c.setFont("Vazir", 7.2)
    c.drawString(MARGIN + w - list_w + 12, cy, "خوانده‌نشده: ۲")
    cy -= 14
    rows = [("مشتری مهمان", "۱۰:۲۴", True), ("کاربر فروشگاه", "۰۹:۴۱", False), ("پشتیبانی پیش‌فروش", "دیروز", False)]
    for name, t, active in rows:
        if active:
            c.setFillColor(C["accent_soft"])
            c.roundRect(MARGIN + w - list_w + 5, cy - 5, list_w - 10, 20, 4, stroke=0, fill=1)
        c.setFillColor(C["ink900"] if active else C["muted"])
        c.setFont("Vazir-Semi" if active else "Vazir", 7.6)
        c.drawRightString(MARGIN + w - 12, cy, visual(name))
        c.setFillColor(C["subtle"])
        c.setFont("Vazir", 6.8)
        c.drawString(MARGIN + w - list_w + 12, cy, visual(t))
        cy -= 24
    # رشتهٔ مکالمه
    tx = MARGIN + 12
    tw = w - list_w - 24
    cy = y - 44
    c.setFillColor(C["ink900"])
    c.setFont("Vazir-Semi", 7.8)
    c.drawRightString(MARGIN + tw, cy, visual("مشتری مهمان"))
    c.setFillColor(C["ok"])
    c.circle(tx + 2.6, cy + 2.4, 1.7, stroke=0, fill=1)
    c.setFont("Vazir-Med", 6.6)
    c.drawString(tx + 7, cy, visual("در انتظار پاسخ"))
    cy -= 16
    bubbles = [
        ("in", "سلام، سفارش من چه زمانی ارسال می‌شود؟"),
        ("ai", "سفارش شما دیروز ثبت شده و امروز تحویل پست می‌شود."),
    ]
    for kind, text in bubbles:
        bw = min(tw * 0.82, text_width(visual(text), "Vazir", 7.4) + 16)
        bh = 18.0
        c.setFillColor(C["surface2"] if kind == "in" else C["accent_soft"])
        c.setStrokeColor(C["line"] if kind == "in" else C["accent_soft_line"])
        c.setLineWidth(0.6)
        c.roundRect(MARGIN + tw - bw, cy - bh, bw, bh, 5, stroke=1, fill=1)
        c.setFillColor(C["text"] if kind == "in" else C["accent_ink"])
        c.setFont("Vazir", 7.4)
        c.drawRightString(MARGIN + tw - 8, cy - bh + 6, visual(text))
        cy -= bh + 10
    cy -= 4
    c.setFillColor(C["subtle"])
    c.setFont("Vazir", 6.8)
    c.drawRightString(MARGIN + tw, cy, visual("در صورت نیاز، همین‌جا به اپراتور واگذار کنید"))
    # نوار وضعیت و دکمهٔ ارسال
    cy -= 22
    bx = MARGIN + tw
    for label in ("پاسخ خود را بنویسید…",):
        w = min(tw * 0.66, text_width(visual(label), "Vazir", 7.0) + 18)
        c.setFillColor(C["surface2"])
        c.setStrokeColor(C["line"])
        c.setLineWidth(0.6)
        c.roundRect(bx - w, cy - 13, w, 19, 5, stroke=1, fill=1)
        c.setFillColor(C["subtle"])
        c.setFont("Vazir", 7.0)
        c.drawRightString(bx - 8, cy - 6.4, visual(label))
        c.setFillColor(C["accent"])
        c.roundRect(bx - w - 24, cy - 13, 20, 19, 5, stroke=0, fill=1)
        # فلش ارسال (رو به چپ، هم‌جهت RTL)
        ax, ay = bx - w - 18.4, cy - 3.9
        c.setFillColor(C["surface"])
        c.setStrokeColor(C["surface"])
        c.setLineWidth(1.0)
        path = c.beginPath()
        path.moveTo(ax + 6, ay + 3.2)
        path.lineTo(ax, ay)
        path.lineTo(ax + 6, ay - 3.2)
        c.drawPath(path, stroke=1, fill=0)
    d.y = y - h - 14


def table_block(d: Doc, rows: list[tuple[str, list[str]]], caption: str) -> None:
    """جدول مرجع در قالب کارت‌های سه‌ستونی تا صفحهٔ کمتری مصرف شود."""
    cols = 3
    gap = 10
    col_w = (CONTENT_W - gap * (cols - 1)) / cols
    idx = 0
    while idx < len(rows):
        group = rows[idx : idx + cols]
        # ارتفاع سطر = بیشینهٔ ارتفاع کارت‌ها
        heights = []
        for task, path in group:
            h = 16 + S["sm"] * 1.8 + 12
            if path:
                h += 20
            heights.append(h)
        row_h = max(heights)
        d.need(row_h + 14)
        y = d.y
        for j, (task, path) in enumerate(group):
            x_right = MARGIN + CONTENT_W - j * (col_w + gap)
            x_left = x_right - col_w
            c = d.c
            c.setFillColor(C["surface"])
            c.setStrokeColor(C["line"])
            c.setLineWidth(0.7)
            c.roundRect(x_left, y - row_h, col_w, row_h, 8, stroke=1, fill=1)
            cy = y - 15
            c.setFillColor(C["ink900"])
            c.setFont("Vazir-Semi", S["sm"])
            c.drawRightString(x_right - 9, cy, visual(task))
            if path:
                chip(c, path, cy - 16, x_right=x_right - 9, max_w=col_w - 18)
        d.y = y - row_h - 10
        idx += cols


def checklist(d: Doc, items: list[str]) -> None:
    c = d.c
    cols, gap = 2, 10
    col_w = (CONTENT_W - gap) / cols
    size = S["sm"]
    rows = [items[i : i + cols] for i in range(0, len(items), cols)]
    for row in rows:
        lines_per = [
            wrap_words(it.split(), "Vazir", size, col_w - 26) for it in row
        ]
        row_h = max(34, max(len(l) for l in lines_per) * size * 1.8 + 22)
        d.need(row_h + 10)
        y = d.y
        for j, lines in enumerate(lines_per):
            x_right = MARGIN + CONTENT_W - j * (col_w + gap)
            x_left = x_right - col_w
            c.setFillColor(C["surface"])
            c.setStrokeColor(C["line"])
            c.setLineWidth(0.7)
            c.roundRect(x_left, y - row_h, col_w, row_h, 8, stroke=1, fill=1)
            # مربع خالی چک‌باکس در سمت راست کارت
            c.setFillColor(C["surface2"])
            c.setStrokeColor(C["line_strong"])
            c.setLineWidth(0.8)
            c.roundRect(x_right - 22, y - 20, 11, 11, 3, stroke=1, fill=1)
            cy = y - 18
            c.setFillColor(C["muted"])
            c.setFont("Vazir", size)
            for line in lines:
                c.drawRightString(x_right - 28, cy, get_display(" ".join(shaped_word(w) for w in line)))
                cy -= size * 1.8
        d.y = y - row_h - 10


# ---------------------------------------------------------------------------
# ساخت سند
# ---------------------------------------------------------------------------
def build(d: Doc, data: dict, relay: list[str], *, collect: bool) -> None:
    c = d.c
    d.new_page(footer=False)
    if collect:
        d.collect_toc = True

    # ---------------- جلد ----------------
    d.c.setFillColor(C["ink900"])
    d.c.rect(0, 0, A4_W, A4_H, stroke=0, fill=1)
    # شبکهٔ محو
    c.setStrokeColor(HexColor("#152f37"))
    c.setLineWidth(0.5)
    gx, gy = MARGIN, MARGIN
    while gx < A4_W - MARGIN:
        c.line(gx, MARGIN, gx, A4_H - MARGIN)
        gx += 42
    while gy < A4_H - MARGIN:
        c.line(MARGIN, gy, A4_W - MARGIN, gy)
        gy += 42
    c.setFillColor(C["accent"])
    c.rect(0, 0, 8, A4_H, stroke=0, fill=1)

    top = A4_H - 96
    draw_mark(c, MARGIN + CONTENT_W - 60, top + 22, 60, C["accent_on_dark"], C["accent_on_dark"], C["ink900"])
    c.setFillColor(C["on_dark"])
    c.setFont("Vazir-XBold", 15)
    c.drawRightString(MARGIN + CONTENT_W - 72, top + 14, visual("پاسخ‌بان"))
    c.setFillColor(C["on_dark_muted"])
    c.setFont("Vazir", S["caption"])
    c.drawRightString(MARGIN + CONTENT_W - 72, top - 4, get_display(reshape("افزونهٔ چت هوشمند و پشتیبانی برای وردپرس")))

    y = top - 120
    c.setFillColor(C["accent_on_dark"])
    c.setFont("Vazir-Semi", S["caption"])
    c.drawRightString(MARGIN + CONTENT_W, y, visual(data["eyebrow"]))
    y -= 30
    c.setFillColor(C["on_dark"])
    c.setFont("Vazir-XBold", 25)
    c.drawRightString(MARGIN + CONTENT_W, y, visual(data["title"].rstrip("،")))
    y -= 34
    c.setFillColor(C["accent_on_dark"])
    c.drawRightString(MARGIN + CONTENT_W, y, visual(data["title_accent"]))
    y -= 34
    # متن معرفی
    lead_lines = wrap_words(data["lead"].split(), "Vazir", S["lead"], CONTENT_W - 60)
    c.setFillColor(C["on_dark_muted"])
    c.setFont("Vazir", S["lead"])
    for line in lead_lines:
        c.drawRightString(MARGIN + CONTENT_W, y, get_display(" ".join(shaped_word(w) for w in line)))
        y -= S["lead"] * 1.9
    # چیپ‌های مشخصات
    y -= 10
    for label in data["meta"]:
        w = text_width(visual(label), "Vazir-Med", S["caption"]) + 22
        c.setStrokeColor(C["inkline"])
        c.setFillColor(HexColor("#122f36"))
        c.setLineWidth(0.7)
        c.roundRect(MARGIN + CONTENT_W - w, y - 20, w, 20, 10, stroke=1, fill=1)
        c.setFillColor(C["on_dark_muted"])
        c.setFont("Vazir-Med", S["caption"])
        c.drawCentredString(MARGIN + CONTENT_W - w / 2, y - 14, visual(label))
        y -= 28

    c.setFillColor(C["on_dark_muted"])
    c.setFont("Vazir", S["caption"])
    c.drawRightString(MARGIN + CONTENT_W, MARGIN + 24, visual("اتحاد وردپرس"))

    # ---------------- فهرست ----------------
    d.new_page()
    c.setFillColor(C["ink900"])
    c.setFont("Vazir-Bold", S["h2"])
    c.drawRightString(MARGIN + CONTENT_W, d.y, visual("فهرست راهنما"))
    d.y -= 14
    c.setStrokeColor(C["line"])
    c.setLineWidth(0.8)
    c.line(MARGIN, d.y, MARGIN + CONTENT_W, d.y)
    d.y -= 22
    for sec in data["sections"]:
        page_no = d.toc_pages.get(sec.id)
        y = d.y
        c.setFillColor(C["accent_ink"])
        c.setFont("Vazir-Semi", S["caption"])
        c.drawRightString(MARGIN + CONTENT_W, y, visual(sec.num))
        c.setFillColor(C["text"])
        c.setFont("Vazir-Med", S["h4"])
        c.drawRightString(MARGIN + CONTENT_W - 34, y, visual(sec.title))
        if page_no:
            c.setFillColor(C["subtle"])
            c.setFont("Vazir", S["caption"])
            c.drawString(MARGIN, y, fa_num(page_no))
            c.setStrokeColor(C["line_strong"])
            c.setLineWidth(0.5)
            c.setDash(1, 3)
            c.line(MARGIN + 26, y + 3, MARGIN + CONTENT_W - 42, y + 3)
            c.setDash()
        d.y -= 16
        c.setFillColor(C["muted"])
        c.setFont("Vazir", S["caption"])
        c.drawRightString(MARGIN + CONTENT_W - 34, d.y, visual(sec.lead[:88] + ("…" if len(sec.lead) > 88 else "")))
        d.y -= 26
    d.y -= 6
    note = (
        "این PDF نسخهٔ چاپیِ همان راهنمای فارسی سایت است؛ محتوای هر دو از یک منبع ساخته می‌شود. "
        "برای دیدن نمونه‌ها و متن کامل، نسخهٔ وب را در guide.html باز کنید."
    )
    callout(d, "دربارهٔ این نسخه", note, kind="info")

    # ---------------- فصل‌ها ----------------
    for sec in data["sections"]:
        d.new_page()
        section_head(d, sec)

        if sec.id == "start" or sec.steps:
            for st in sec.steps:
                card(d, st.title, st.body, st.path, badge=st.label)
            if sec.callout:
                d.space(4)
                callout(d, sec.callout[0] or "نکته", sec.callout[1], kind="info")
        if sec.settings:
            for st in sec.settings:
                card(d, st.title, st.body, st.path)
        if sec.channels:
            for blk in sec.channels:
                card(d, blk.title, blk.intro, blk.path or None)
                if blk.steps:
                    d.space(2)
                    for i, line in enumerate(blk.steps, start=1):
                        numbered_item(d, fa_num(i), line)
                    d.space(6)
                if blk.code:
                    d.space(4)
                    code_block(d, blk.code, "google-relay.gs")
                    callout(
                        d,
                        "کد همین صفحه، قابل انتخاب در نسخهٔ وب",
                        "در نسخهٔ وب همین راهنما، دکمهٔ «کپی کل کد» و «دانلود فایل» بالای همین بلوک قرار دارد؛ "
                        "در این PDF می‌توانید متن بالا را انتخاب و کپی کنید.",
                        kind="info",
                    )
                if blk.warn_body:
                    callout(d, blk.warn_title or "توجه", blk.warn_body, kind="warn")
                d.space(8)
        if sec.mock:
            product_mock(d)
        if sec.prose:
            for kind, text in sec.prose:
                if kind == "p" and text.startswith("پاسخ‌بان") and "بررسی سلامت" in text:
                    # این پاراگراف در HTML فقط یک چیپ مسیر است
                    d.space(2)
                    parts = [t for t in re.split(r"\s+", text) if t]
                    d.need(26)
                    chip(d.c, parts, d.y - 4, x_right=MARGIN + CONTENT_W)
                    d.y -= 24
                    d.space(6)
                    continue
                if kind == "h3":
                    d.space(4)
                    d.need(40)
                    c.setFillColor(C["ink900"])
                    c.setFont("Vazir-Bold", S["h3"])
                    c.drawRightString(MARGIN + CONTENT_W, d.y, visual(text))
                    d.y -= 16
                else:
                    d.paragraph(text, size=S["sm"], color=C["muted"], gap_after=8)
        if sec.faq:
            for q, a in sec.faq:
                d.need(70)
                y = d.y
                c.setFillColor(C["accent_soft"])
                c.roundRect(MARGIN + CONTENT_W - 20, y - 1, 20, 15, 4, stroke=0, fill=1)
                c.setFillColor(C["accent_ink"])
                c.setFont("Vazir-Semi", S["micro"])
                c.drawCentredString(MARGIN + CONTENT_W - 10, y + 3.4, visual("پ"))
                c.setFillColor(C["ink900"])
                c.setFont("Vazir-Semi", S["h4"])
                c.drawRightString(MARGIN + CONTENT_W - 27, y, visual(q))
                d.y = y - 17
                d.space(2)
                d.paragraph(a, size=S["sm"], color=C["muted"], gap_after=16)
        if sec.checklist:
            checklist(d, sec.checklist)
        if sec.table:
            d.space(4)
            c.setFillColor(C["subtle"])
            c.setFont("Vazir", S["caption"])
            c.drawRightString(MARGIN + CONTENT_W, d.y, visual(sec.table_caption))
            d.y -= 14
            table_block(d, sec.table, sec.table_caption)
        if sec.callout and sec.id not in ("start",):
            callout(d, sec.callout[0] or "توجه", sec.callout[1], kind="warn" if sec.id == "reference" else "info")


def main() -> None:
    register_fonts()
    load_coverage()
    data = extract()
    relay = relay_lines()

    # بازرسی پوشش فونت روی کل متن سند
    all_text = [data["title"], data["title_accent"], data["lead"], data["eyebrow"], *data["meta"]]
    for sec in data["sections"]:
        all_text += [sec.title, sec.lead, sec.eyebrow, sec.num]
        all_text += [s.title + s.body + " ".join(s.path) for s in sec.steps]
        all_text += [s.title + s.body + " ".join(s.path) for s in sec.settings]
        for b in sec.channels:
            all_text += [b.title, b.intro, b.warn_title, b.warn_body, " ".join(b.path), *b.steps]
        for k, t in sec.prose:
            all_text.append(t)
        for q, a in sec.faq:
            all_text += [q, a]
        all_text += sec.checklist
        all_text += [t + " ".join(p) for t, p in sec.table]
        if sec.callout:
            all_text += list(sec.callout)
    missing = missing_chars(" ".join(all_text), ("Vazir", "Vazir-Med", "Vazir-Semi", "Vazir-Bold", "Vazir-XBold", "Mono"))
    if missing:
        sys.exit("این نویسه‌ها در فونت‌ها نیستند: " + " ".join(f"{ch} (U+{ord(ch):04X})" for ch in sorted(missing)))

    # گذر اول: پیدا کردن شمارهٔ صفحهٔ فصل‌ها
    probe = Doc(os.devnull if os.name != "nt" else "NUL")
    probe.c = rl_canvas.Canvas(os.devnull, pagesize=(A4_W, A4_H))
    probe.collect_toc = True
    build(probe, data, relay, collect=True)
    toc_pages = dict(probe.toc_pages)
    del probe

    # گذر دوم: ساخت نهایی با شماره‌صفحه‌ها
    final = Doc(OUT_PDF)
    final.toc_pages = toc_pages
    build(final, data, relay, collect=False)
    final.finish()
    print(f"✅ PDF ساخته شد: {OUT_PDF}")
    print(f"   صفحه‌ها: {final.page} · شماره‌صفحهٔ فصل‌ها: {toc_pages}")
    print(f"   حجم: {os.path.getsize(OUT_PDF) / 1024:.0f} KB")


if __name__ == "__main__":
    main()
